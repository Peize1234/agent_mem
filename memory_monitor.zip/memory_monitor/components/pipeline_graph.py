from __future__ import annotations

import html
from dataclasses import dataclass
from typing import Any, Mapping

from memory_monitor.models import (
    FOREGROUND_STEPS,
    MEMORY_STEPS,
    PIPELINE_STEPS,
    TERMINAL_STEP_STATUSES,
    VISIBLE_PIPELINE_STEPS,
    BackgroundStepConfig,
    PipelineStep,
    StepStatus,
)

_STEP_LABELS = {
    PipelineStep.CAPTURE_INPUT: "捕获输入",
    PipelineStep.RETRIEVE_CONTEXT: "检索上下文",
    PipelineStep.BUILD_PROMPT: "构建 Prompt",
    PipelineStep.GENERATE_RESPONSE: "模型回答",
    PipelineStep.RUN_SHORTTERM: "添加短期记忆",
    PipelineStep.RUN_MIDTERM: "添加中期记忆",
    PipelineStep.RUN_LONGTERM: "添加长期记忆",
    PipelineStep.RUN_PROFILE: "抽取用户画像",
    PipelineStep.COMPLETE_TURN: "完成本轮",
}
_STATUS_LABELS = {
    StepStatus.PENDING.value: "pending · 等待",
    StepStatus.QUEUED.value: "queued · 已排队",
    StepStatus.RUNNING.value: "running · 执行中",
    StepStatus.SUCCEEDED.value: "succeeded · 成功",
    StepStatus.FAILED.value: "failed · 可重试",
    StepStatus.SKIPPED.value: "skipped · 系统不适用",
}


@dataclass(frozen=True)
class PipelineNode:
    step: PipelineStep
    label: str
    status: str
    attempts: int
    duration_ms: float | None
    error: str | None
    enabled: bool
    current: bool
    held: bool = False
    detail: str | None = None


def build_nodes(
    steps: list[dict[str, Any]],
    background_config: BackgroundStepConfig | Mapping[str, object] | None,
) -> dict[PipelineStep, PipelineNode]:
    # Retain the argument for callers that still load legacy per-turn config;
    # current memory controls derive exclusively from persisted step holds.
    del background_config
    step_map = {PipelineStep(item["step"]): item for item in steps}
    complete_status = completion_status(steps)
    current_step = _current_step(step_map, complete_status)
    nodes = {}
    for step in VISIBLE_PIPELINE_STEPS:
        if step is PipelineStep.COMPLETE_TURN:
            item = {"status": complete_status, "attempts": 0}
        else:
            item = step_map[step]
        nodes[step] = PipelineNode(
            step=step,
            label=_STEP_LABELS[step],
            status=item["status"],
            attempts=int(item.get("attempts") or 0),
            duration_ms=item.get("duration_ms"),
            error=item.get("error_message"),
            enabled=not bool(item.get("is_held")),
            current=step is current_step,
            held=bool(item.get("is_held")),
            detail=_node_detail(step, item, step_map),
        )
    return nodes


def completion_status(steps: list[dict[str, Any]]) -> str:
    step_map = {PipelineStep(item["step"]): item for item in steps}
    if step_map[PipelineStep.GENERATE_RESPONSE]["status"] != StepStatus.SUCCEEDED.value:
        return StepStatus.PENDING.value
    statuses = [step_map[step]["status"] for step in MEMORY_STEPS]
    if all(status in TERMINAL_STEP_STATUSES for status in statuses):
        return StepStatus.SUCCEEDED.value
    if StepStatus.FAILED.value in statuses:
        return StepStatus.FAILED.value
    if StepStatus.RUNNING.value in statuses:
        return StepStatus.RUNNING.value
    if StepStatus.QUEUED.value in statuses:
        return StepStatus.QUEUED.value
    return StepStatus.PENDING.value


def progress(
    steps: list[dict[str, Any]],
    background_config: BackgroundStepConfig | Mapping[str, object] | None = None,
) -> tuple[int, int, float]:
    step_map = {PipelineStep(item["step"]): item for item in steps}
    completed = sum(step_map[step]["status"] in TERMINAL_STEP_STATUSES for step in PIPELINE_STEPS)
    complete = completion_status(steps) == StepStatus.SUCCEEDED.value
    total = len(PIPELINE_STEPS) + 1
    completed += int(complete)
    return completed, total, completed / total


def render_html(
    steps: list[dict[str, Any]],
    background_config: BackgroundStepConfig | Mapping[str, object] | None,
) -> str:
    nodes = build_nodes(steps, background_config)
    completed, total, _ratio = progress(steps, background_config)
    foreground = '<div class="demo-arrow">→</div>'.join(_node_html(nodes[step]) for step in FOREGROUND_STEPS)
    branches = "".join(f'<div class="demo-memory-branch">{_node_html(nodes[step])}</div>' for step in MEMORY_STEPS)
    return (
        '<div class="demo-pipeline">'
        '<div class="demo-pipeline-summary">'
        f"<span>实时进度 {completed}/{total}</span>"
        "<span>四个记忆分支使用独立有序队列</span>"
        "</div>"
        '<div class="demo-pipeline-scroll">'
        '<div class="demo-flow-row">'
        f'<div class="demo-foreground-chain">{foreground}</div>'
        f'<div class="demo-fork" aria-hidden="true">{_render_fork_svg()}</div>'
        f'<div class="demo-memory-column">{branches}</div>'
        f'<div class="demo-merge" aria-hidden="true">{_render_merge_svg()}</div>'
        f'<div class="demo-complete-node">{_node_html(nodes[PipelineStep.COMPLETE_TURN])}</div>'
        "</div>"
        "</div>"
        "</div>"
    )


def _render_fork_svg() -> str:
    arms = "".join(
        f'<line class="demo-connector-arm demo-fork-output" x1="50" y1="{center}" '
        f'x2="96" y2="{center}" marker-end="url(#demo-fork-arrow)" />'
        for center in (12.5, 37.5, 62.5, 87.5)
    )
    return (
        '<svg class="demo-connector-svg" width="100%" height="100%" viewBox="0 0 100 100" '
        'preserveAspectRatio="none">'
        '<defs><marker id="demo-fork-arrow" viewBox="0 0 6 6" refX="5" refY="3" '
        'markerWidth="5" markerHeight="5" orient="auto" markerUnits="strokeWidth">'
        '<path d="M 0 0 L 6 3 L 0 6 z" class="demo-connector-arrowhead" /></marker></defs>'
        '<line class="demo-connector-input" x1="0" y1="50" x2="47" y2="50" '
        'marker-end="url(#demo-fork-arrow)" />'
        '<line class="demo-connector-trunk" x1="50" y1="12.5" x2="50" y2="87.5" />'
        f"{arms}</svg>"
    )


def _render_merge_svg() -> str:
    arms = "".join(
        f'<line class="demo-connector-arm demo-merge-input" x1="0" y1="{center}" x2="50" y2="{center}" />'
        for center in (12.5, 37.5, 62.5, 87.5)
    )
    return (
        '<svg class="demo-connector-svg" width="100%" height="100%" viewBox="0 0 100 100" '
        'preserveAspectRatio="none">'
        '<defs><marker id="demo-merge-arrow" viewBox="0 0 6 6" refX="5" refY="3" '
        'markerWidth="5" markerHeight="5" orient="auto" markerUnits="strokeWidth">'
        '<path d="M 0 0 L 6 3 L 0 6 z" class="demo-connector-arrowhead" /></marker></defs>'
        f"{arms}"
        '<line class="demo-connector-trunk" x1="50" y1="12.5" x2="50" y2="87.5" />'
        '<line class="demo-connector-output" x1="50" y1="50" x2="96" y2="50" '
        'marker-end="url(#demo-merge-arrow)" />'
        "</svg>"
    )


def _node_html(node: PipelineNode) -> str:
    classes = ["demo-node", node.status]
    if node.current:
        classes.append("current")
    if not node.enabled:
        classes.append("disabled")
    if node.held:
        classes.append("held")
    duration = f" · {node.duration_ms:.0f} ms" if node.duration_ms is not None else ""
    tooltip = ' title="四个记忆步骤全部完成后，本轮自动完成"' if node.step is PipelineStep.COMPLETE_TURN else ""
    error = ""
    if node.error:
        short_error = node.error[:90] + ("…" if len(node.error) > 90 else "")
        error = f'<div class="demo-node-error" title="{html.escape(node.error)}">{html.escape(short_error)}</div>'
    detail = f'<div class="demo-node-detail">{html.escape(node.detail)}</div>' if node.detail else ""
    attempts = "" if node.step is PipelineStep.COMPLETE_TURN else f"{node.attempts} 次{duration}"
    return (
        f'<div class="{" ".join(classes)}"{tooltip}>'
        f'<div class="demo-node-title">{html.escape(node.label)}</div>'
        f'<div class="demo-node-status">{html.escape(_node_status_label(node))}</div>'
        f'<div class="demo-node-meta">{attempts}</div>'
        f"{detail}{error}</div>"
    )


def _node_detail(
    step: PipelineStep,
    item: dict[str, Any],
    step_map: dict[PipelineStep, dict[str, Any]],
) -> str | None:
    if step is PipelineStep.COMPLETE_TURN:
        return None
    if item["status"] == StepStatus.PENDING.value and item.get("is_held"):
        return "重新勾选后继续执行"
    if item["status"] == StepStatus.FAILED.value:
        return "选择该失败节点可单独重试"
    if step in MEMORY_STEPS[1:] and item["status"] == StepStatus.PENDING.value:
        shortterm_status = step_map[PipelineStep.RUN_SHORTTERM]["status"]
        if shortterm_status == StepStatus.FAILED.value:
            return "短期提交失败，等待重试"
        if shortterm_status != StepStatus.SUCCEEDED.value:
            return "等待短期记忆完成"
    return None


def _node_status_label(node: PipelineNode) -> str:
    if node.status == StepStatus.PENDING.value and node.held:
        return "pending · 已阻塞"
    if node.status == StepStatus.PENDING.value and node.step in MEMORY_STEPS[1:] and node.detail:
        return "pending · 等待依赖"
    return _STATUS_LABELS.get(node.status, node.status)


def _current_step(
    step_map: dict[PipelineStep, dict[str, Any]],
    complete_status: str,
) -> PipelineStep | None:
    for status in (
        StepStatus.RUNNING.value,
        StepStatus.QUEUED.value,
        StepStatus.FAILED.value,
        StepStatus.PENDING.value,
    ):
        match = next((step for step in PIPELINE_STEPS if step_map[step]["status"] == status), None)
        if match is not None:
            return match
    return PipelineStep.COMPLETE_TURN if complete_status == StepStatus.SUCCEEDED.value else None
