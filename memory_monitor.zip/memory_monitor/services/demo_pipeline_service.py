from __future__ import annotations

import json
import threading
import time
from copy import deepcopy
from typing import Any, Dict, Optional

from memory_monitor.models import (
    FOREGROUND_STEPS,
    MEMORY_STEPS,
    OPTIONAL_PIPELINE_STEPS,
    PIPELINE_STEPS,
    TERMINAL_STEP_STATUSES,
    BackgroundStepConfig,
    PipelineStep,
    StepStatus,
    dependencies_for,
)
from memory_monitor.runtime.demo_background_coordinator import DemoBackgroundCoordinator, SubmissionResult
from memory_monitor.services.demo_repository import DemoRepository
from memory_monitor.services.memory_state_service import MemoryStateService

TARGET_ANSWER = "answer"
TARGET_MEMORY = "memory"
TARGET_ALL = "all"


class PipelineStepError(RuntimeError):
    """Wrap a step failure with the scope needed to diagnose and retry it."""


class BackgroundJobDeferred(RuntimeError):
    """The core queue cannot claim this job yet because an earlier job owns its stage."""


class DemoPipelineService:
    """Persisted asynchronous DAG orchestration composed around ``DemoMemory``."""

    def __init__(
        self,
        memory,
        repository: DemoRepository,
        state_service: MemoryStateService,
        *,
        coordinator: DemoBackgroundCoordinator | None = None,
        generation_kwargs: Optional[Dict[str, Any]] = None,
    ):
        self.memory = memory
        self.repository = repository
        self.state_service = state_service
        self.coordinator = coordinator
        self.generation_kwargs = deepcopy(generation_kwargs) if generation_kwargs else {}
        self._schedule_lock = threading.RLock()

    def create_turn(
        self,
        session_id: str,
        *,
        user_id: str,
        run_id: str,
        user_message: str,
        turn_id: Optional[str] = None,
        background_config: BackgroundStepConfig | Dict[str, Any] | None = None,
    ) -> Dict[str, Any]:
        return self.repository.create_turn(
            session_id,
            user_id=user_id,
            run_id=run_id,
            user_message=user_message,
            turn_id=turn_id,
            background_config=background_config,
        )

    def update_background_config(
        self,
        turn_id: str,
        config: BackgroundStepConfig | Dict[str, Any],
        *,
        session_id: str,
    ) -> Dict[str, Any]:
        self._require_turn(turn_id, session_id)
        return self.repository.update_background_config(turn_id, config)

    def run_next_step(self, turn_id: str, *, session_id: str) -> Dict[str, Any]:
        turn = self._require_turn(turn_id, session_id)
        step_runs = self._step_map(turn_id)
        inflight = next(
            (
                step
                for step in PIPELINE_STEPS
                if step_runs[step]["status"] in {StepStatus.QUEUED.value, StepStatus.RUNNING.value}
            ),
            None,
        )
        if inflight is not None:
            return {"turn_id": turn_id, "blocked": "running", "step": inflight.value}
        failed = next(
            (step for step in PIPELINE_STEPS if step_runs[step]["status"] == StepStatus.FAILED.value),
            None,
        )
        if failed is not None:
            return {"turn_id": turn_id, "blocked": "failed", "step": failed.value}

        if turn.get("completed_at") is not None:
            return {"turn_id": turn_id, "complete": True}

        for step in FOREGROUND_STEPS:
            current = step_runs[step]
            if current["status"] != StepStatus.PENDING.value:
                continue
            if self._prerequisites_complete(turn_id, step):
                result = self._submit_step(turn_id, step, session_id)
                return self._submission_payload(turn_id, {step: result})

        if step_runs[PipelineStep.GENERATE_RESPONSE]["status"] == StepStatus.SUCCEEDED.value:
            return self.run_memory_stage(turn_id, session_id=session_id)
        return {"turn_id": turn_id, "complete": False}

    def run_step(
        self,
        turn_id: str,
        step: PipelineStep | str,
        *,
        session_id: str,
    ) -> SubmissionResult | Dict[str, Any]:
        step = PipelineStep(step)
        if step not in PIPELINE_STEPS:
            raise ValueError(f"Pipeline step is not executable: {step.value}")
        self._require_turn(turn_id, session_id)
        existing = self._require_step(turn_id, step)
        if self._is_complete(existing) or existing["status"] in {
            StepStatus.QUEUED.value,
            StepStatus.RUNNING.value,
        }:
            return existing
        if existing["status"] == StepStatus.FAILED.value:
            raise ValueError(f"Use retry_step for a failed step: turn={turn_id} step={step.value}")
        self._require_not_held(existing)
        self._require_prerequisites(turn_id, step)
        if step in MEMORY_STEPS:
            self.repository.mark_background_submitted(turn_id)
        return self._submit_step(turn_id, step, session_id)

    def retry_step(
        self,
        turn_id: str,
        step: PipelineStep | str,
        *,
        session_id: str,
    ) -> SubmissionResult:
        self._require_turn(turn_id, session_id)
        step = PipelineStep(step)
        current = self._require_step(turn_id, step)
        if current["status"] != StepStatus.FAILED.value:
            raise ValueError(f"Only failed steps can be retried: turn={turn_id} step={step.value}")
        self._require_not_held(current)
        self._require_prerequisites(turn_id, step)
        return self._submit_step(turn_id, step, session_id, retry=True)

    def retryable_steps(self, turn_id: str, *, session_id: str) -> list[Dict[str, Any]]:
        self._require_turn(turn_id, session_id)
        return [step for step in self.repository.list_steps(turn_id) if step["status"] == StepStatus.FAILED.value]

    def hold_step(
        self,
        turn_id: str,
        step: PipelineStep | str,
        *,
        session_id: str,
    ) -> Dict[str, Any]:
        """Persistently prevent automatic scheduling while keeping the step pending."""
        self._require_turn(turn_id, session_id)
        step = PipelineStep(step)
        if step not in MEMORY_STEPS:
            raise ValueError(f"Only pending memory steps can be held: {step.value}")
        return self.repository.hold_step(turn_id, step)

    def release_step(
        self,
        turn_id: str,
        step: PipelineStep | str,
        *,
        session_id: str,
    ) -> Dict[str, Any]:
        """Release a held memory step and submit it immediately when dependencies allow."""
        self._require_turn(turn_id, session_id)
        step = PipelineStep(step)
        released = self.repository.release_step(turn_id, step)
        if not self._prerequisites_complete(turn_id, step):
            return {
                "turn_id": turn_id,
                "released": True,
                "scheduled": False,
                "step": released,
            }
        self.repository.mark_background_submitted(turn_id)
        submission = self._submit_step(turn_id, step, session_id)
        return self._submission_payload(turn_id, {step: submission})

    def skip_step(
        self,
        turn_id: str,
        step: PipelineStep | str,
        *,
        session_id: str,
        reason: str = "Disabled by turn configuration",
    ) -> Dict[str, Any]:
        """Compatibility alias for the recoverable memory-step hold operation."""
        step = PipelineStep(step)
        if step not in OPTIONAL_PIPELINE_STEPS:
            raise ValueError(f"Pipeline step is not configurable: {step.value}")
        return self.hold_step(turn_id, step, session_id=session_id)

    def run_until(
        self,
        turn_id: str,
        target_step: PipelineStep | str,
        *,
        session_id: str,
    ) -> Dict[str, Any]:
        target_step = PipelineStep(target_step)
        if target_step is not PipelineStep.GENERATE_RESPONSE:
            raise ValueError("run_until only supports generate_response in the asynchronous pipeline")
        return self.run_to_answer(turn_id, session_id=session_id)

    def run_to_answer(self, turn_id: str, *, session_id: str) -> Dict[str, Any]:
        self._require_turn(turn_id, session_id)
        self.repository.set_execution_target(turn_id, TARGET_ANSWER)
        submissions = self._advance_turn(turn_id, session_id)
        return self._submission_payload(turn_id, submissions, execution_target=TARGET_ANSWER)

    def run_memory_stage(self, turn_id: str, *, session_id: str) -> Dict[str, Any]:
        self._require_turn(turn_id, session_id)
        generation = self._require_step(turn_id, PipelineStep.GENERATE_RESPONSE)
        if generation["status"] != StepStatus.SUCCEEDED.value:
            raise RuntimeError("模型回答完成后才能运行记忆阶段")
        self.repository.set_execution_target(turn_id, TARGET_MEMORY)
        submissions = self._schedule_memory_batch(turn_id, session_id)
        return self._submission_payload(turn_id, submissions, execution_target=TARGET_MEMORY)

    def run_all(self, turn_id: str, *, session_id: str) -> Dict[str, Any]:
        self._require_turn(turn_id, session_id)
        self.repository.set_execution_target(turn_id, TARGET_ALL)
        submissions = self._advance_turn(turn_id, session_id)
        return self._submission_payload(turn_id, submissions, execution_target=TARGET_ALL)

    def run_remaining(self, turn_id: str, *, session_id: str) -> Dict[str, Any]:
        return self.run_all(turn_id, session_id=session_id)

    def submit_background_branches(
        self,
        turn_id: str,
        *,
        session_id: str,
    ) -> Dict[str, Any]:
        return self.run_memory_stage(turn_id, session_id=session_id)

    def has_running_background(self, turn_id: str) -> bool:
        return any(
            step["status"] in {StepStatus.QUEUED.value, StepStatus.RUNNING.value}
            for step in self.repository.list_steps(turn_id)
        )

    def reset_turn(self, turn_id: str, *, session_id: str) -> Dict[str, Any]:
        self._require_turn(turn_id, session_id)
        self.repository.reset_turn(turn_id)
        return self._require_turn(turn_id, session_id)

    def resume_pending_work(self) -> None:
        self.repository.recover_expired_step_leases()
        for turn in self.repository.list_scheduled_turns():
            self._advance_turn(turn["turn_id"], turn["session_id"])

    def _advance_turn(
        self,
        turn_id: str,
        session_id: str,
    ) -> dict[PipelineStep, SubmissionResult]:
        with self._schedule_lock:
            turn = self._require_turn(turn_id, session_id)
            target = turn.get("execution_target")
            if target not in {TARGET_ANSWER, TARGET_MEMORY, TARGET_ALL}:
                return {}
            step_runs = self._step_map(turn_id)

            if target in {TARGET_ANSWER, TARGET_ALL}:
                for step in FOREGROUND_STEPS:
                    status = step_runs[step]["status"]
                    if status == StepStatus.FAILED.value or status in {
                        StepStatus.QUEUED.value,
                        StepStatus.RUNNING.value,
                    }:
                        return {}
                    if status == StepStatus.PENDING.value:
                        result = self._submit_step(turn_id, step, session_id)
                        return {step: result}
                if target == TARGET_ANSWER:
                    self.repository.set_execution_target(turn_id, None)
                    return {}

            if target in {TARGET_MEMORY, TARGET_ALL}:
                return self._schedule_memory_batch(turn_id, session_id)
            return {}

    def _schedule_memory_batch(
        self,
        turn_id: str,
        session_id: str,
    ) -> dict[PipelineStep, SubmissionResult]:
        """Submit short-term once, then fan out all eligible memory branches."""
        with self._schedule_lock:
            turn = self._require_turn(turn_id, session_id)
            step_runs = self._step_map(turn_id)
            if step_runs[PipelineStep.GENERATE_RESPONSE]["status"] != StepStatus.SUCCEEDED.value:
                return {}

            if turn.get("background_submitted_at") is None:
                self.repository.mark_background_submitted(turn_id)

            # The persisted target remains active while any branch is held.
            # Re-read step rows after recording the batch intent.
            step_runs = self._step_map(turn_id)
            shortterm = step_runs[PipelineStep.RUN_SHORTTERM]
            if shortterm["status"] == StepStatus.FAILED.value or shortterm["status"] in {
                StepStatus.QUEUED.value,
                StepStatus.RUNNING.value,
            }:
                return {}
            if shortterm["status"] == StepStatus.PENDING.value:
                if shortterm.get("is_held"):
                    return {}
                result = self._submit_step(turn_id, PipelineStep.RUN_SHORTTERM, session_id)
                return {PipelineStep.RUN_SHORTTERM: result}

            eligible = []
            for step in MEMORY_STEPS[1:]:
                current = step_runs[step]
                if current["status"] != StepStatus.PENDING.value:
                    continue
                if current.get("is_held"):
                    continue
                if self._prerequisites_complete(turn_id, step):
                    eligible.append(step)
            submissions = (
                self.coordinator.submit_enabled_branches(
                    turn_id,
                    session_id,
                    tuple(eligible),
                    self._run_claimed_step,
                    on_settled=self._on_step_settled,
                )
                if eligible and self.coordinator is not None
                else {}
            )
            if not submissions and all(step_runs[step]["status"] in TERMINAL_STEP_STATUSES for step in MEMORY_STEPS):
                self.repository.set_execution_target(turn_id, None)
            return submissions

    def _submit_step(
        self,
        turn_id: str,
        step: PipelineStep,
        session_id: str,
        *,
        retry: bool = False,
    ) -> SubmissionResult:
        if self.coordinator is None:
            raise RuntimeError("Demo background coordinator is not configured")
        return self.coordinator.submit(
            turn_id,
            step,
            session_id,
            self._run_claimed_step,
            retry=retry,
            on_settled=self._on_step_settled,
        )

    def _on_step_settled(self, turn_id: str, step: PipelineStep, session_id: str) -> None:
        current = self._require_step(turn_id, step)
        if current["status"] in {
            StepStatus.SUCCEEDED.value,
            StepStatus.SKIPPED.value,
            StepStatus.FAILED.value,
        }:
            self._advance_turn(turn_id, session_id)

    def _run_claimed_step(
        self,
        turn_id: str,
        step: PipelineStep,
        token: str,
        session_id: str,
    ) -> Dict[str, Any]:
        turn = self._require_turn(turn_id, session_id)
        self._require_prerequisites(turn_id, step)
        started_at = time.perf_counter()
        input_data: Dict[str, Any] = {}
        before = None
        before_id = None
        after_id = None
        diff: Dict[str, Any] = {}
        mutates_memory = step in MEMORY_STEPS
        try:
            input_data = self._step_input(turn, step)
            if mutates_memory:
                before, before_id, snapshot_error = self._capture_snapshot(turn, step, "before")
                if snapshot_error:
                    diff["before_snapshot_error"] = snapshot_error
            output, turn_updates = self._execute(turn, step, input_data)
            if mutates_memory:
                after, after_id, snapshot_error = self._capture_snapshot(turn, step, "after")
                if snapshot_error:
                    diff["after_snapshot_error"] = snapshot_error
                if before is not None and after is not None:
                    diff.update(self.state_service.compare(before, after))
            duration_ms = (time.perf_counter() - started_at) * 1000
            return self.repository.complete_step(
                turn_id,
                step,
                token,
                input_data=input_data,
                output_data=output,
                duration_ms=duration_ms,
                before_snapshot_id=before_id,
                after_snapshot_id=after_id,
                diff=diff,
                assistant_message=turn_updates.get("assistant_message"),
                generation=turn_updates.get("generation"),
                commit=turn_updates.get("commit"),
            )
        except BackgroundJobDeferred as exc:
            duration_ms = (time.perf_counter() - started_at) * 1000
            return self.repository.defer_step(
                turn_id,
                step,
                token,
                input_data=input_data,
                reason=str(exc),
                duration_ms=duration_ms,
                before_snapshot_id=before_id,
                after_snapshot_id=after_id,
                diff=diff,
            )
        except Exception as exc:
            duration_ms = (time.perf_counter() - started_at) * 1000
            self.repository.fail_step(
                turn_id,
                step,
                token,
                input_data=input_data,
                error=exc,
                duration_ms=duration_ms,
                before_snapshot_id=before_id,
                after_snapshot_id=after_id,
                diff=diff,
            )
            raise PipelineStepError(
                "Demo pipeline step failed: "
                f"step={step.value} user_id={turn['user_id']} session_id={turn['session_id']} "
                f"run_id={turn['run_id']} turn_id={turn_id}: {exc}"
            ) from exc

    def _capture_snapshot(
        self,
        turn: Dict[str, Any],
        step: PipelineStep,
        phase: str,
    ) -> tuple[Dict[str, Any] | None, str | None, str | None]:
        try:
            snapshot = self.state_service.snapshot(user_id=turn["user_id"], run_id=turn["run_id"])
            snapshot_id = self.repository.create_snapshot(turn["turn_id"], step, phase, snapshot)
            return snapshot, snapshot_id, None
        except Exception as exc:
            return None, None, f"{type(exc).__name__}: {exc}"

    def _execute(
        self,
        turn: Dict[str, Any],
        step: PipelineStep,
        input_data: Dict[str, Any],
    ) -> tuple[Any, Dict[str, Any]]:
        turn_id = turn["turn_id"]
        if step is PipelineStep.CAPTURE_INPUT:
            return deepcopy(input_data), {}

        if step is PipelineStep.RETRIEVE_CONTEXT:
            context = self.memory.retrieve_context_for_demo(
                turn["user_message"],
                user_id=turn["user_id"],
                session_id=turn["run_id"],
            )
            return context, {}

        if step is PipelineStep.BUILD_PROMPT:
            context = self._step_output(turn_id, PipelineStep.RETRIEVE_CONTEXT)
            prompt = self.memory.build_prompt_from_context(context)
            return {"context_hash": self.memory.context_hash(context), "messages": prompt}, {}

        if step is PipelineStep.GENERATE_RESPONSE:
            prompt_output = self._step_output(turn_id, PipelineStep.BUILD_PROMPT)
            messages = prompt_output["messages"]
            raw_response = self.memory.generate_response_for_demo(messages, **self.generation_kwargs)
            assistant_message = self._assistant_text(raw_response)
            output = {
                "context_hash": prompt_output["context_hash"],
                "prompt_messages": messages,
                "assistant_message": assistant_message,
                "raw_response": raw_response,
            }
            return output, {"assistant_message": assistant_message, "generation": output}

        if step is PipelineStep.RUN_SHORTTERM:
            generation = self._step_output(turn_id, PipelineStep.GENERATE_RESPONSE)
            session = self.repository.get_session(turn["session_id"])
            if session is None:
                raise KeyError(f"Unknown demo session: {turn['session_id']}")
            result = self.memory.commit_demo_turn(
                simulation_id=session["simulation_id"],
                turn_id=turn_id,
                user_id=turn["user_id"],
                run_id=turn["run_id"],
                user_message=turn["user_message"],
                assistant_message=generation["assistant_message"],
            )
            return result, {"commit": result}

        if step in MEMORY_STEPS[1:]:
            return self._run_background_job(turn_id, step), {}

        raise ValueError(f"Unsupported pipeline step: {step.value}")

    def _run_background_job(self, turn_id: str, step: PipelineStep) -> Dict[str, Any]:
        commit = self._step_output(turn_id, PipelineStep.RUN_SHORTTERM)
        background = commit.get("background") or {}
        worker = self.memory.demo_background_worker
        if step is PipelineStep.RUN_PROFILE:
            job_type = "profile"
            job_id = background.get("profile_job_id")
            status_field = "status"
            processor = worker.process_profile_job
            stage = None
        else:
            job_type = "migration"
            job_id = background.get("migration_job_id")
            stage = "midterm" if step is PipelineStep.RUN_MIDTERM else "longterm"
            status_field = f"{stage}_status"
            processor = worker.process_midterm_job if step is PipelineStep.RUN_MIDTERM else worker.process_longterm_job
        if not job_id:
            return {
                "job_type": job_type,
                "job_id": None,
                "processed": False,
                "status": "not_created",
            }

        event_offset = len(self.memory.demo_events())
        processed = processor(job_id)
        status = worker.get_job_status(job_id, job_type)
        status_name = (status or {}).get(status_field)
        if status_name not in {"succeeded", "succeeded_degraded"}:
            if not processed and status_name in {"pending", "running", "retry"}:
                raise BackgroundJobDeferred(
                    f"{step.value} is waiting for an earlier core queue item: job_id={job_id} status={status_name}"
                )
            raise RuntimeError(
                f"{step.value} job did not complete successfully: "
                f"job_id={job_id} status={status_name} processed={processed}"
            )
        events = [
            event
            for event in self.memory.demo_events()[event_offset:]
            if event.get("job_id") == job_id and (stage is None or event.get("stage") in {None, stage})
        ]
        return {
            "job_type": job_type,
            "pipeline_step": step.value,
            "job_id": job_id,
            "processed": processed,
            "status": status_name,
            "job": status,
            "events": events,
        }

    def _step_input(self, turn: Dict[str, Any], step: PipelineStep) -> Dict[str, Any]:
        turn_id = turn["turn_id"]
        if step is PipelineStep.CAPTURE_INPUT:
            return {
                "turn_id": turn_id,
                "user_id": turn["user_id"],
                "run_id": turn["run_id"],
                "user_message": turn["user_message"],
            }
        if step is PipelineStep.RETRIEVE_CONTEXT:
            return {"query": turn["user_message"], "user_id": turn["user_id"], "run_id": turn["run_id"]}
        if step is PipelineStep.BUILD_PROMPT:
            context = self._step_output(turn_id, PipelineStep.RETRIEVE_CONTEXT)
            return {"context_hash": self.memory.context_hash(context)}
        if step is PipelineStep.GENERATE_RESPONSE:
            prompt = self._step_output(turn_id, PipelineStep.BUILD_PROMPT)
            return {"context_hash": prompt["context_hash"], "messages": prompt["messages"]}
        if step is PipelineStep.RUN_SHORTTERM:
            generation = self._step_output(turn_id, PipelineStep.GENERATE_RESPONSE)
            return {
                "turn_id": turn_id,
                "session_id": turn["session_id"],
                "user_message": turn["user_message"],
                "assistant_message": generation["assistant_message"],
            }
        if step in MEMORY_STEPS[1:]:
            commit = self._step_output(turn_id, PipelineStep.RUN_SHORTTERM)
            background = commit.get("background") or {}
            job_id = (
                background.get("profile_job_id")
                if step is PipelineStep.RUN_PROFILE
                else background.get("migration_job_id")
            )
            return {"pipeline_step": step.value, "job_id": job_id}
        raise ValueError(f"Unsupported pipeline step: {step.value}")

    def _require_prerequisites(self, turn_id: str, step: PipelineStep) -> None:
        incomplete = [
            prerequisite.value
            for prerequisite in dependencies_for(step, self.repository.background_config(turn_id))
            if not self._is_complete(self._require_step(turn_id, prerequisite))
        ]
        if incomplete:
            raise RuntimeError(
                f"Pipeline prerequisites are incomplete for turn={turn_id} step={step.value}: {incomplete}"
            )

    def _prerequisites_complete(self, turn_id: str, step: PipelineStep) -> bool:
        return all(
            self._is_complete(self._require_step(turn_id, prerequisite))
            for prerequisite in dependencies_for(step, self.repository.background_config(turn_id))
        )

    @staticmethod
    def _require_not_held(step: Dict[str, Any]) -> None:
        if step.get("is_held"):
            raise RuntimeError(f"Pipeline step is held: step={step['step']}")

    def _step_output(self, turn_id: str, step: PipelineStep) -> Any:
        step_run = self._require_step(turn_id, step)
        if step_run["status"] != StepStatus.SUCCEEDED.value:
            raise RuntimeError(f"Required step has not succeeded: turn={turn_id} step={step.value}")
        return deepcopy(step_run.get("output"))

    def _require_turn(self, turn_id: str, session_id: str) -> Dict[str, Any]:
        return self.repository.assert_turn_belongs_to_session(turn_id, session_id)

    def _require_step(self, turn_id: str, step: PipelineStep) -> Dict[str, Any]:
        step_run = self.repository.get_step(turn_id, step)
        if step_run is None:
            raise KeyError(f"Unknown demo step: turn={turn_id} step={step.value}")
        return step_run

    def _step_map(self, turn_id: str) -> dict[PipelineStep, Dict[str, Any]]:
        return {PipelineStep(item["step"]): item for item in self.repository.list_steps(turn_id)}

    @staticmethod
    def _is_complete(step: Dict[str, Any]) -> bool:
        return step["status"] in TERMINAL_STEP_STATUSES

    @staticmethod
    def _submission_payload(
        turn_id: str,
        submissions: dict[PipelineStep, SubmissionResult],
        *,
        execution_target: str | None = None,
    ) -> Dict[str, Any]:
        return {
            "turn_id": turn_id,
            "scheduled": True,
            "execution_target": execution_target,
            "submissions": {
                step.value: {
                    "submitted": result.submitted,
                    "status": result.status,
                    "reason": result.reason,
                }
                for step, result in submissions.items()
            },
        }

    @staticmethod
    def _assistant_text(response: Any) -> str:
        if isinstance(response, str):
            text = response
        elif isinstance(response, dict):
            text = response.get("content") or response.get("text") or response.get("message")
            if isinstance(text, dict):
                text = text.get("content")
            if text is None:
                text = json.dumps(response, ensure_ascii=False, default=str)
        else:
            text = getattr(response, "content", None) or str(response)
        text = str(text).strip()
        if not text:
            raise ValueError("The answer model returned an empty response")
        return text
